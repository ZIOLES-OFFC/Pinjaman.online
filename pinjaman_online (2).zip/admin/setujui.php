<?php
include '../config/koneksi.php';
session_start();
if ($_SESSION['role'] !== 'admin') die("Unauthorized");

$id = $_GET['id'];
$jumlah = $_GET['jumlah'];
$bunga = 0.02;

$stmt = $conn->prepare("UPDATE pengajuan SET status='disetujui', jumlah=?, bunga=?, tanggal_disetujui=NOW() WHERE id=?");
$stmt->bind_param("ddi", $jumlah, $bunga, $id);
$stmt->execute();

echo "Pengajuan disetujui dan jumlah ditentukan.";
?>