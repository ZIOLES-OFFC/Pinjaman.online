<?php
include '../config/koneksi.php';
session_start();

if ($_SESSION['role'] !== 'admin') die("Unauthorized");

$result = $conn->query("SELECT p.*, u.nama FROM pengajuan p JOIN users u ON p.user_id = u.id WHERE p.status = 'pending'");

while ($row = $result->fetch_assoc()) {
    echo "Nama: " . $row['nama'] . " - Jumlah: " . $row['jumlah'] . " - Tenor: " . $row['tenor'];
    echo " <a href='setujui.php?id=" . $row['id'] . "'>Setujui</a> | ";
    echo "<a href='tolak.php?id=" . $row['id'] . "'>Tolak</a><br>";
}
?>