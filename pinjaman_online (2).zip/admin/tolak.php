<?php
include '../config/koneksi.php';
session_start();
if ($_SESSION['role'] !== 'admin') die("Unauthorized");

$id = $_GET['id'];
$conn->query("UPDATE pengajuan SET status='ditolak' WHERE id=$id");
echo "Pengajuan ditolak.";
?>