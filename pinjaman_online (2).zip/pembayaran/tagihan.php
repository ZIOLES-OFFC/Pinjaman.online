<?php
include '../config/koneksi.php';
session_start();
if ($_SESSION['role'] !== 'user') die("Unauthorized");

$user_id = $_SESSION['user_id'];
$query = "SELECT c.* FROM cicilan c JOIN pengajuan p ON c.pengajuan_id = p.id WHERE p.user_id = $user_id AND c.status = 'belum dibayar'";
$result = $conn->query($query);

while ($row = $result->fetch_assoc()) {
    echo "Bulan ke-{$row['bulan_ke']}, Jumlah: {$row['jumlah']}, Jatuh tempo: {$row['jatuh_tempo']}<br>";
}
?>