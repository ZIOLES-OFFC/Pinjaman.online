<?php
include '../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $nik = $_POST['nik'];
    $no_hp = $_POST['no_hp'];
    $alamat = $_POST['alamat'];

    $stmt = $conn->prepare("INSERT INTO users (nama, email, password, nik, no_hp, alamat) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $nama, $email, $password, $nik, $no_hp, $alamat);

    if ($stmt->execute()) {
        echo "Registrasi berhasil. Silakan verifikasi via Telegram.";
    } else {
        echo "Registrasi gagal: " . $conn->error;
    }
}
?>