<?php
include '../config/koneksi.php';
session_start();
if ($_SESSION['role'] !== 'user') die("Unauthorized");

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM pengajuan WHERE user_id = $user_id ORDER BY id DESC LIMIT 1");
$data = $result->fetch_assoc();

echo "Status Pinjaman Terakhir: " . $data['status'] . "<br>Jumlah: " . $data['jumlah'];
?>