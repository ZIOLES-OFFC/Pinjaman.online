<?php
// File: telegram_webhook.php

include 'config/koneksi.php'; // Pastikan file koneksi.php ada dan benar

$update = json_decode(file_get_contents("php://input"), TRUE);

if (isset($update["message"])) {
    $chat_id = $update["message"]["chat"]["id"];
    $text = $update["message"]["text"];

    // Format perintah: /verifikasi [email] [NIK]
    if (strpos($text, '/verifikasi') === 0) {
        $parts = explode(" ", $text);

        if (count($parts) == 3) {
            $email = $parts[1];
            $nik = $parts[2];

            // Cek di database
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND nik = ?");
            $stmt->bind_param("ss", $email, $nik);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Update status verifikasi
                $updateStmt = $conn->prepare("UPDATE users SET verified = 1 WHERE email = ? AND nik = ?");
                $updateStmt->bind_param("ss", $email, $nik);
                $updateStmt->execute();
                $msg = "✅ Verifikasi berhasil! Akun $email sudah terverifikasi.";
            } else {
                $msg = "Data tidak ditemukan. Pastikan email dan NIK benar.";
            }
        } else {
            $msg = "Format salah. Gunakan: /verifikasi [email] [NIK]";
        }

        // Kirim balasan ke Telegram
        $token = "<YOUR_BOT_TOKEN>"; // Ganti dengan token bot Telegram kamu
        $url = "https://api.telegram.org/bot$token/sendMessage";

        $data = [
            'chat_id' => $chat_id,
            'text' => $msg
        ];

        $options = [
            'http' => [
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'method'  => 'POST',
                'content' => http_build_query($data),
            ],
        ];
        $context  = stream_context_create($options);
        file_get_contents($url, false, $context);
    }
}
?>