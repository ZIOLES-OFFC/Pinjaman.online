<?php
include '../config/koneksi.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_SESSION['role'] === 'user') {
    $user_id = $_SESSION['user_id'];
    $id_owner = $_POST['id_owner']; // Owner ID ditentukan saat pengajuan
    $tenor = $_POST['tenor'];
    
    // Owner akan menentukan jumlah dan bunga nanti, default kosong/dummy
    $jumlah = 0;
    $bunga = 0.02;

    $stmt = $conn->prepare("INSERT INTO pengajuan (user_id, id_owner, jumlah, tenor, bunga, status) VALUES (?, ?, ?, ?, ?, 'pending')");
    $stmt->bind_param("iiddd", $user_id, $id_owner, $jumlah, $tenor, $bunga);

    if ($stmt->execute()) {
        echo "Pengajuan berhasil dikirim. Menunggu keputusan owner.";
    } else {
        echo "Gagal mengirim pengajuan.";
    }
}
?>